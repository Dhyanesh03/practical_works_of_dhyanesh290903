/*/package com.hexaware.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {
	private static Connection connection;

	public static Connection getConnection() {
		if (connection == null) {
			try (InputStream input = DBConnection.class.getClassLoader().getResourceAsStream("db.properties")) {
				Properties prop = new Properties();
				if (input == null) {
					System.out.println("Sorry, unable to find db.properties");
					return null;
				}
				prop.load(input);
				String url = prop.getProperty("");
				String user = prop.getProperty("db.user");
				String password = prop.getProperty("db.password");
				connection = DriverManager.getConnection(url, user, password);
			} catch (SQLException | IOException ex) {
				ex.printStackTrace();
			}
		}
		return connection;
	}
}*/

package com.hexaware.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    private static Connection connection;

    public static Connection getConnection() {
        if (connection == null) {
            try {
                // Load MySQL JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");
                String url = "jdbc:mysql://localhost:3306/assetmngmt";
                String username = "root";  // Replace with your DB username
                String password = "Hexaware@12345";  // Replace with your DB password
                connection = DriverManager.getConnection(url, username, password);
                System.out.println("Connection established successfully.");
            } catch (ClassNotFoundException e) {
                System.err.println("MySQL JDBC Driver not found.");
                e.printStackTrace();
            } catch (SQLException e) {
                System.err.println("Failed to establish connection.");
                e.printStackTrace(); // This will show errors related to DB connection issues
            }
        }
        return connection;
    }
}