package com.hexaware.main;

import java.sql.Date;
import java.util.Scanner;

import com.hexaware.assetmanagement.Asset;
import com.hexaware.dao.AssetManagementService;
import com.hexaware.dao.AssetManagementServiceImpl;

public class AssetManagementApp {
    public static void main(String[] args) {
        AssetManagementService service = new AssetManagementServiceImpl();
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println("1. Add Asset");
            System.out.println("2. Update Asset");
            System.out.println("3. Delete Asset");
            System.out.println("4. Allocate Asset");
            System.out.println("5. Deallocate Asset");
            System.out.println("6. Perform Maintenance");
            System.out.println("7. Reserve Asset");
            System.out.println("8. Withdraw Reservation");
            System.out.println("9. Exit");
            System.out.print("Choose an option: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                	System.out.println("Enter asset_id:");
                	int assetId=scanner.nextInt();
                    System.out.println("Enter asset name: ");
                    String name = scanner.nextLine();
                    System.out.println("Enter asset type: ");
                    String type = scanner.nextLine();
                    System.out.println("Enter serial number: ");
                    String serialNumber = scanner.nextLine();
                    System.out.println("Enter purchase date (YYYY-MM-DD): ");
                    String purchaseDateStr = scanner.nextLine();
                    Date purchaseDate=Date.valueOf(purchaseDateStr);
                    System.out.println("Enter location: ");
                    String location = scanner.nextLine();
                    System.out.println("Enter status: ");
                    String status = scanner.nextLine();
                    System.out.println("Enter owner ID: ");
                    int ownerId = scanner.nextInt();
                    Asset newAsset = new Asset(0, name, type, purchaseDateStr, purchaseDate, location, status, ownerId);
                    if (service.addAsset(newAsset)) {
                        System.out.println("Asset added successfully.");
                    } else {
                        System.out.println("Failed to add asset.");
                    }
                    break;
                case 2:
                    System.out.print("Enter asset ID to update: ");
                    int updateAssetId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter new asset name: ");
                    String newName = scanner.nextLine();
                    System.out.print("Enter new asset type: ");
                    String newType = scanner.nextLine();
                    System.out.print("Enter new serial number: ");
                    String newSerialNumber = scanner.nextLine();
                    System.out.print("Enter new purchase date (YYYY-MM-DD): ");
                    String newPurchaseDate = scanner.nextLine();
                    Date purchaseDateDate=Date.valueOf(newPurchaseDate);
                    System.out.print("Enter new location: ");
                    String newLocation = scanner.nextLine();
                    System.out.print("Enter new status: ");
                    String newStatus = scanner.nextLine();
                    System.out.print("Enter new owner ID: ");
                    int newOwnerId = scanner.nextInt();
                    Asset updatedAsset = new Asset(updateAssetId, newName, newType, newSerialNumber, purchaseDateDate, newLocation, newStatus, newOwnerId);
                    if (service.updateAsset(updatedAsset)) {
                        System.out.println("Asset updated successfully.");
                    } else {
                        System.out.println("Failed to update asset.");
                    }
                    break;
                case 3:
                    System.out.print("Enter asset ID to delete: ");
                    int deleteAssetId = scanner.nextInt();
                    if (service.deleteAsset(deleteAssetId)) {
                        System.out.println("Asset deleted successfully.");
                    } else {
                        System.out.println("Failed to delete asset.");
                    }
                    break;
                case 4:
                    System.out.print("Enter asset ID to allocate: ");
                    int allocateAssetId = scanner.nextInt();
                    System.out.print("Enter employee ID to allocate to: ");
                    int allocateEmployeeId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter allocation date (YYYY-MM-DD): ");
                    String allocationDate = scanner.nextLine();
                    if (service.allocateAsset(allocateAssetId, allocateEmployeeId, allocationDate)) {
                        System.out.println("Asset allocated successfully.");
                    } else {
                        System.out.println("Failed to allocate asset.");
                    }
                    break;
                case 5:
                    System.out.print("Enter asset ID to deallocate: ");
                    int deallocateAssetId = scanner.nextInt();
                    System.out.print("Enter employee ID to deallocate from: ");
                    int deallocateEmployeeId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter return date (YYYY-MM-DD): ");
                    String returnDate = scanner.nextLine();
                    if (service.deallocateAsset(deallocateAssetId, deallocateEmployeeId, returnDate)) {
                        System.out.println("Asset deallocated successfully.");
                    } else {
                        System.out.println("Failed to deallocate asset.");
                    }
                    break;
                case 6:
                    System.out.print("Enter asset ID for maintenance: ");
                    int maintenanceAssetId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter maintenance date (YYYY-MM-DD): ");
                    String maintenanceDate = scanner.nextLine();
                    System.out.print("Enter maintenance description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter maintenance cost: ");
                    double cost = scanner.nextDouble();
                    if (service.performMaintenance(maintenanceAssetId, maintenanceDate, description, cost)) {
                        System.out.println("Maintenance recorded successfully.");
                    } else {
                        System.out.println("Failed to record maintenance.");
                    }
                    break;
                case 7:
                    System.out.print("Enter asset ID to reserve: ");
                    int reserveAssetId = scanner.nextInt();
                    System.out.print("Enter employee ID to reserve for: ");
                    int reserveEmployeeId = scanner.nextInt();
                    scanner.nextLine(); // Consume newline
                    System.out.print("Enter reservation date (YYYY-MM-DD): ");
                    String reservationDate = scanner.nextLine();
                    System.out.print("Enter start date (YYYY-MM-DD): ");
                    String startDate = scanner.nextLine();
                    System.out.print("Enter end date (YYYY-MM-DD): ");
                    String endDate = scanner.nextLine();
                    if (service.reserveAsset(reserveAssetId, reserveEmployeeId, reservationDate, startDate, endDate)) {
                        System.out.println("Asset reserved successfully.");
                    } else {
                        System.out.println("Failed to reserve asset.");
                    }
                    break;
                case 8:
                    System.out.print("Enter reservation ID to withdraw: ");
                    int reservationId = scanner.nextInt();
                    if (service.withdrawReservation(reservationId)) {
                        System.out.println("Reservation withdrawn successfully.");
                    } else {
                        System.out.println("Failed to withdraw reservation.");
                    }
                    break;
                case 9:
                    System.out.println("Exiting...");
                    System.exit(0);
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
