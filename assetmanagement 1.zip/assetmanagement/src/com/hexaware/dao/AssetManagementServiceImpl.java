package com.hexaware.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.util.Calendar;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.hexaware.assetmanagement.*;
import com.hexaware.util.DBConnection;

public class AssetManagementServiceImpl implements AssetManagementService {
    Connection connection;

    public AssetManagementServiceImpl() {
        this.connection = DBConnection.getConnection(); // Removed null parameter
    }
    @Override
    public boolean addAsset(Asset asset) {

String query = "INSERT INTO assets (asset_id, name,type, serial_number, purchase_date, location,status, owner_id) VALUES(?, ?, ?, ?, ?, ?, ?, ?)";
        
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, asset.getAssetId());
            stmt.setString(2, asset.getName());
            stmt.setString(3, asset.getType());
            stmt.setString(4, asset.getSerialNumber());
            stmt.setDate(5, asset.getPurchaseDate()); // Properly convert java.util.Date to java.sql.Date
            stmt.setString(6, asset.getLocation());
            stmt.setString(7, asset.getStatus());
            stmt.setInt(8, asset.getOwnerId());
            return stmt.executeUpdate(query) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }}


    @Override
    public boolean updateAsset(Asset asset) {
        String query = "UPDATE assets SET name = ?, type = ?, serial_number = ?, purchase_date = ?, location = ?, status = ?, owner_id = ? WHERE asset_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, asset.getName());
            stmt.setString(2, asset.getType());
            stmt.setString(3, asset.getSerialNumber());
            stmt.setDate(4,asset.getPurchaseDate());
            stmt.setString(5, asset.getLocation());
            stmt.setString(6, asset.getStatus());
            stmt.setInt(7, asset.getOwnerId());
            stmt.setInt(8, asset.getAssetId());
            return stmt.executeUpdate(query) > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deleteAsset(int assetId) {
        String query = "DELETE FROM assets WHERE asset_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, assetId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean allocateAsset(int assetId, int employeeId, String allocationDate) {
        String query = "INSERT INTO asset_allocations (asset_id, employee_id, allocation_date) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, assetId);
            stmt.setInt(2, employeeId);
            stmt.setDate(3, java.sql.Date.valueOf(allocationDate));
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean deallocateAsset(int assetId, int employeeId, String returnDate) {
        String query = "UPDATE asset_allocations SET return_date = ? WHERE asset_id = ? AND employee_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, java.sql.Date.valueOf(returnDate));
            stmt.setInt(2, assetId);
            stmt.setInt(3, employeeId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost) {
        String query = "INSERT INTO maintenance_records (asset_id, maintenance_date, description, cost) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, assetId);
            stmt.setDate(2, java.sql.Date.valueOf(maintenanceDate));
            stmt.setString(3, description);
            stmt.setDouble(4, cost);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate) {
        String query = "INSERT INTO reservations (asset_id, employee_id, reservation_date, start_date, end_date, status) VALUES (?, ?, ?, ?, ?, 'pending')";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, assetId);
            stmt.setInt(2, employeeId);
            stmt.setDate(3, java.sql.Date.valueOf(reservationDate));
            stmt.setDate(4, java.sql.Date.valueOf(startDate));
            stmt.setDate(5, java.sql.Date.valueOf(endDate));
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    @Override
    public boolean withdrawReservation(int reservationId) {
        String query = "DELETE FROM reservations WHERE reservation_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, reservationId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
