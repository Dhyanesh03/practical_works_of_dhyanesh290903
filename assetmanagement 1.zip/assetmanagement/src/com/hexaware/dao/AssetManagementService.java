package com.hexaware.dao;

import com.hexaware.assetmanagement.Asset;

public interface AssetManagementService {
    boolean addAsset(Asset newasset);
    boolean updateAsset(Asset newasset);
    boolean deleteAsset(int assetId);
    boolean allocateAsset(int assetId, int employeeId, String allocationDate);
    boolean deallocateAsset(int assetId, int employeeId, String returnDate);
    boolean performMaintenance(int assetId, String maintenanceDate, String description, double cost);
    boolean reserveAsset(int assetId, int employeeId, String reservationDate, String startDate, String endDate);
    boolean withdrawReservation(int reservationId);
}
