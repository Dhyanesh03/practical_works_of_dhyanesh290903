package com.hexaware.polymorphisim;

public class Overloading {
	public static void sum(int a,int b) {
		System.out.println("Sum(int a,int b) invoked");
	}
	public static void sum(String a,String b) {
		System.out.println("Sum(int a,int b) invoked");
	}
	public static void sum(int a,int b,int c) {
		System.out.println("Sum(int a,int b,int c) invoked");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
            sum(1,2);
            sum(1,2,3);
            sum("a","b");
	}

}
