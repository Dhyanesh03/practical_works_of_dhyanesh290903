package com.hexaware.overriding;

public class ICICI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
