package com.hexaware.overriding;

public class Mainmod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
