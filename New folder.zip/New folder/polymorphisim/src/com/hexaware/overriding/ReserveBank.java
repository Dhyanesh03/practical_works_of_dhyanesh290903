package com.hexaware.overriding;

public class ReserveBank {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
