package com.hexaware.interfaceDemo;

public class bankImpl implements Ibank {

}s