package com.hexaware.interfaceDemo;

public interface Ibank {

}
