package matrixmultiplication;

import java.util.Scanner;

public class matrixmultiplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[][]=new int[4][4];
		int b[][]=new int[4][4];
		int result[][]=new int[4][4];
		int number;
		Scanner scan= new Scanner(System.in);
		System.out.print("Enter the coulunm and rows number  ");
		number =scan.nextInt();
		System.out.print("Enter values of First Matrix  ");
		for(int i=0;i<number;i++)
			for(int j=0;j<number;j++)
				a[i][j]=scan.nextInt();
		System.out.print("Enter values of Second Matrix  ");
		for(int i=0;i<number;i++)
			for(int j=0;j<number;j++)
				a[i][j]=scan.nextInt();
		System.out.print("muliplied Matrix  ");
		for(int i=0;i<number;i++)
			for(int j=0;j<number;j++)
				result[i][j]=a[i][j]*b[i][j];
        
		for(int i=0;i<number;i++)
			for(int j=0;j<number;j++) {
				System.out.print(result[i][j]+" ");
			}
		System.out.println();
				
	}  

}
