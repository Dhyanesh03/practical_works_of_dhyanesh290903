package com.hexaware.mainmod;

import java.util.*;

import com.hexaware.customexception.AccountNotFoundExcpetion;
import com.hexaware.customexception.InsufficentBalanceException;
import com.hexaware.entity.AccountType;
import com.hexaware.entity.Bank;
import com.hexaware.entity.BankAccount;
import com.hexaware.service.BankServiceImpl;

public class MainMod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BankAccount obj1 = new BankAccount(1100450034L, "Dhyanesh", 13456.76, AccountType.CURRENT);
		BankAccount obj2 = new BankAccount(1100460035L, "HariniSri", 16456.76, AccountType.SAVINGS);
		BankAccount obj3 = new BankAccount(1100470036L, "Kishore", 17456.76, AccountType.CURRENT);
		BankAccount obj4 = new BankAccount(11004880037L, "SuriyaPriya", 15456.76, AccountType.SAVINGS);
		BankAccount obj5 = new BankAccount(1100490038L, "SasiRekha", 19456.76, AccountType.SAVINGS);

		//BankAccount[] accountArray = { obj1, obj2, obj3, obj4, obj5 };
		//accountArray[0]=obj1;
		//accountArray[1]=obj2;
		//accountArray[2]=obj3;
		//accountArray[3]=obj4;
		//accountArray[4]=obj5;
		List<BankAccount> accountArray=new LinkedList();
		accountArray.add(obj1);
		accountArray.add(obj2);
		accountArray.add(obj3);
		accountArray.add(obj4);
		accountArray.add(obj5);
		Bank mybank = new Bank("HDFC", "HDFC0J57", accountArray);
		BankServiceImpl impl = new BankServiceImpl(mybank);
		try {
			System.out.println("Balance amount 1" + impl.checkbalance(1100470035L, 0));
		} catch (AccountNotFoundExcpetion e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println("Withdrawn amount1" + impl.withdrawMoney(1100460035L, 400500));
		} catch (AccountNotFoundExcpetion e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InsufficentBalanceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println("Balance amount 1" + impl.checkbalance(1100460035L, 0));
		} catch (AccountNotFoundExcpetion e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println("Balance amount 2" + impl.checkbalance(1100470036L, 0));
		} catch (AccountNotFoundExcpetion e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println("Deposit Status 2" + impl.depositMoney(1100460036L, 12500));
		} catch (AccountNotFoundExcpetion e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			System.out.println("Balance amount 2" + impl.checkbalance(1100460036L, 0));
		} catch (AccountNotFoundExcpetion e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		impl.displayAllAccounts();
	}

}
