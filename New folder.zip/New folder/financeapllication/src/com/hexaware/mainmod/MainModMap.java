package com.hexaware.mainmod;

import java.util.HashMap;
import java.util.Map;

import com.hexaware.customexception.AccountNotFoundExcpetion;
import com.hexaware.entity.AccountType;
import com.hexaware.entity.BankAccount;
import com.hexaware.service.BankServiceImplMap;

public class MainModMap {

	public static void main(String[] args) throws AccountNotFoundExcpetion {
		// TODO Auto-generated method stub
		BankAccount obj1 = new BankAccount(1100450034L, "Dhyanesh", 13456.76, AccountType.CURRENT);
		BankAccount obj2 = new BankAccount(1100460035L, "HariniSri", 16456.76, AccountType.SAVINGS);
		BankAccount obj3 = new BankAccount(1100470036L, "Kishore", 17456.76, AccountType.CURRENT);
		BankAccount obj4 = new BankAccount(11004880037L, "SuriyaPriya", 15456.76, AccountType.SAVINGS);
		BankAccount obj5 = new BankAccount(1100490038L, "SasiRekha", 19456.76, AccountType.SAVINGS);
		Map<Long,BankAccount> bankMap=new HashMap();
		bankMap.put(1100450034L,obj1);
		bankMap.put(1100460035L, obj2);
		bankMap.put(1100470036L, obj3);
		bankMap.put(110048880037L, obj4);
		bankMap.put(1100490038L, obj5);
		
		BankServiceImplMap implMap=new BankServiceImplMap(bankMap);
		implMap.displayAllAccounts();

		try {
			System.out.println("Searched account"+implMap.searchAccount(1100460035L));
		} catch (AccountNotFoundExcpetion e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}

}
