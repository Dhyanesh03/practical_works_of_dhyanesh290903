package com.hexaware.entity;

public enum AccountType{
	SAVINGS,
	CURRENT,
}
