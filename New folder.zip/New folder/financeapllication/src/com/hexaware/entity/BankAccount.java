package com.hexaware.entity;

public class BankAccount {
	private long accountnumber;
	private String holdername;
	private double balance;
	private AccountType type;

	public BankAccount(long accountnumber, String holdername, double balance, AccountType type) {
		super();
		this.accountnumber = accountnumber;
		this.holdername = holdername;
		this.balance = balance;
		this.setType(type);
	}
	
	public long getAccountnumber() {
		return accountnumber;
	}
	public void setAccountnumber(long accountnumber) {
		this.accountnumber = accountnumber;
	}
	public String getHoldername() {
		return holdername;
	}
	public void setHoldername(String holdername) {
		this.holdername = holdername;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "BankAccount [accountnumber=" + accountnumber + ", holdername=" + holdername + ", balance=" + balance
				+ "]";
	}
	public AccountType getType() {
		return type;
	}
	public void setType(AccountType type) {
		this.type = type;
	}

}
