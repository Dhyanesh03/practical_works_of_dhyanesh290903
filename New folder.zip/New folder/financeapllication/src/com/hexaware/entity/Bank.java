package com.hexaware.entity;

import java.util.Arrays;
import java.util.List;

public class Bank {
	private String bankName;
	private String ifscCode;
	private List<BankAccount> accountArray;
	public Bank(String bankName, String ifscCode, List<BankAccount> accountArray) {
		super();
		this.bankName = bankName;
		this.ifscCode = ifscCode;
		this.accountArray = accountArray;
	}
	public Bank() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public <BankAccout> List<BankAccount> getAccountArray() {
		return accountArray;
	}
	public void setAccountArray(List<BankAccount> accountArray) {
		this.accountArray = accountArray;
	}
	@Override
	public String toString() {
		return "Bank [bankName=" + bankName + ", ifscCode=" + ifscCode + ", accountArray=" + accountArray + "]";
	}
	
	

}
