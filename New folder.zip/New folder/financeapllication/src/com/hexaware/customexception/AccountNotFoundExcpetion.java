package com.hexaware.customexception;

public class AccountNotFoundExcpetion extends Exception {
	public AccountNotFoundExcpetion(String message) {
		super("BAnk Account Not found..."+message);
	}

}
