package com.hexaware.customexception;

public class InsufficentBalanceException extends Exception {
	public  InsufficentBalanceException(String message) {
		super("INsufficent balance....."+message);
	}
}
