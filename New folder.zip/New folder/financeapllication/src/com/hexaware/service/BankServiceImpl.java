package com.hexaware.service;

import java.util.Iterator;
import java.util.ListIterator;

import com.hexaware.customexception.AccountNotFoundExcpetion;
import com.hexaware.customexception.InsufficentBalanceException;
import com.hexaware.entity.Bank;
import com.hexaware.entity.BankAccount;

public class BankServiceImpl implements IBankService {
	private Bank mybank;

	public BankAccount searchAccount(long AccountNumber) throws AccountNotFoundExcpetion {
		BankAccount requiredAccount = null;
		for (BankAccount account : this.mybank.getAccountArray()) {
			if (account.getAccountnumber() == AccountNumber) {
				requiredAccount = account;
				break;
			}
		}
		if (requiredAccount == null) {
			throw new AccountNotFoundExcpetion("NO Account Found");
		}
		return requiredAccount;

	}

	@Override
	public double checkbalance(Long AccountNumber, double amount) throws AccountNotFoundExcpetion {
		// TODO Auto-generated method stub
		double balance = -1;
		BankAccount requiredAccount = searchAccount(AccountNumber);
		return balance = requiredAccount.getBalance();

	}

	public BankServiceImpl(Bank mybank) {
		super();
		this.mybank = mybank;
	}

	@Override
	public boolean withdrawMoney(Long AccountNumber, double amount)
			throws AccountNotFoundExcpetion, InsufficentBalanceException {
		// TODO Auto-generated method stub
		boolean withdrawStatus = false;
		BankAccount requiredAccount = null;
		requiredAccount = searchAccount(AccountNumber);

		if (requiredAccount == null) {
			throw new AccountNotFoundExcpetion("NO Account Found");
		} else {
			if (requiredAccount.getBalance() < amount) {
				throw new InsufficentBalanceException("INsufficent balance....");
			} else {
				requiredAccount.setBalance(requiredAccount.getBalance() - amount);
				withdrawStatus = true;
			}
		}
		return withdrawStatus;
	}

	@Override
	public boolean depositMoney(Long AccountNumber, double amount) throws AccountNotFoundExcpetion {
		// TODO Auto-generated method stub
		boolean depositStatus = false;
		BankAccount requiredAccount = null;
		requiredAccount = searchAccount(AccountNumber);

		if (requiredAccount == null) {
			throw new AccountNotFoundExcpetion("NO Account Found");
		} else {

			requiredAccount.setBalance(requiredAccount.getBalance() + amount);
			depositStatus = true;
		}

		return depositStatus;
	}
	@Override
	public void displayAllAccounts() {
		Iterator<BankAccount> itrobj = this.mybank.getAccountArray().iterator();
		while(itrobj.hasNext()) {
			System.out.println(itrobj.next());
		}
	
	System.out.println("Method--->2 Enhanced for loop");
	for(BankAccount account:this.mybank.getAccountArray()) {
		System.out.println(account);
	}
	System.out.println("Method--->3 for each");
	this.mybank.getAccountArray().forEach(System.out::println);
	System.out.println("Method--->4");
	ListIterator<BankAccount> itrobj2 =this.mybank.getAccountArray();
			listIterator(this.mybank.getAccountArray().size());
	while(itrobj2.hasPrevious()) {
		System.out.println(itrobj2.previous());
	}

	}
}
