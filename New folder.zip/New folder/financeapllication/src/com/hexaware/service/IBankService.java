package com.hexaware.service;

import com.hexaware.customexception.AccountNotFoundExcpetion;
import com.hexaware.customexception.InsufficentBalanceException;
import com.hexaware.entity.BankAccount;

public interface IBankService {
		public double checkbalance(Long AccountNumber,double amount) throws AccountNotFoundExcpetion;
		public boolean withdrawMoney(Long AccountNumber,double amount) throws AccountNotFoundExcpetion,InsufficentBalanceException;
		public boolean depositMoney(Long AccountNumber,double amount)throws AccountNotFoundExcpetion,InsufficentBalanceException;
		public BankAccount searchAccount(long AccountNumber) throws AccountNotFoundExcpetion;
		public void displayAllAccounts();
		

}
