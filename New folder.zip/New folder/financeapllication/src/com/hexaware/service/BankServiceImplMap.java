package com.hexaware.service;

import java.util.Map;
import java.util.Map.Entry;

import com.hexaware.customexception.AccountNotFoundExcpetion;
import com.hexaware.customexception.InsufficentBalanceException;
import com.hexaware.entity.BankAccount;

public class BankServiceImplMap<BankMap> implements IBankService {
	private Map<Long,BankAccount> bankMap;

	public BankServiceImplMap(Map<Long, BankAccount> bankMap2) {
		// TODO Auto-generated constructor stub
		this.bankMap=bankMap2;
	}

	@Override
	public double checkbalance(Long AccountNumber, double amount) throws AccountNotFoundExcpetion {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean withdrawMoney(Long AccountNumber, double amount)
			throws AccountNotFoundExcpetion, InsufficentBalanceException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean depositMoney(Long AccountNumber, double amount)
			throws AccountNotFoundExcpetion, InsufficentBalanceException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public BankAccount searchAccount(long AccountNumber) throws AccountNotFoundExcpetion {
		// TODO Auto-generated method stub
		BankAccount required = null;
		for (Entry<Long,BankAccount> entryobj:this.bankMap.entrySet()) {
			if (entryobj.getKey() == AccountNumber) {
				required =entryobj.getValue();
				break;
			}
		}
		if (required == null) {
			throw new AccountNotFoundExcpetion("NO Account Found");
		}
		return required;
		
	}

	@Override
	public void displayAllAccounts() {
		// TODO Auto-generated method stub
		for(Entry<Long,BankAccount> entryobj:bankMap.entrySet()) {
			System.out.println(entryobj.getKey()+"=> "+entryobj.getValue());
		}
		
	}

}
