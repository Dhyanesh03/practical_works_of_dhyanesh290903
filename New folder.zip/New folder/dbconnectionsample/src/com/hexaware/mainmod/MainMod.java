package com.hexaware.mainmod;

import java.util.ArrayList;
import java.util.List;

import com.hexaware.entities.Employee;
import com.hexaware.services.ServiceProviderImpl;
import com.hexaware.util.JDBCUtil;

public class MainMod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(JDBCUtil.getConnection(null));
		ServiceProviderImpl impl=new ServiceProviderImpl();
		//System.out.println("Table creation State....."+impl.createEmployeeTable());
		//System.out.println("Record insertion State....."+impl.createEmployeeRecord(new Employee(100,"Sanjeev",789000)));
		//Employee o1=new Employee(101,"Harini",567890);
		//Employee o2=new Employee(102,"kishore",568890);
		//Employee o3=new Employee(103,"Dhyanesh",569890);
		//List<Employee> mylist=new ArrayList();
		//mylist.add(o1);
		//mylist.add(o2);
		//mylist.add(o3);
		//impl.createEmployeeRecords(mylist);
		//System.out.println("updated the table"+impl.updateRecordById(new Employee(101,"Harini Sri",5678890)));
		System.out.println("The table employee"+impl.displayAllEmployee());
		
	}

}
