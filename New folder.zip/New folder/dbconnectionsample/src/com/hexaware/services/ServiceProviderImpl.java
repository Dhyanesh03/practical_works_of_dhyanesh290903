package com.hexaware.services;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.hexaware.entities.Employee;
import com.hexaware.util.JDBCUtil;

public class ServiceProviderImpl implements IServiceProvider {

	@Override
	public boolean createEmployeeTable() {
		// TODO Auto-generated method stub
		boolean createStatus = false;
		Connection conn = null;
		Statement statement = null;

		String query = "create table EMPLOYEE(" + "EMPLOYEE_ID INT NOT NULL, " + "NAME VARCHAR(20) NOT NULL, "
				+ "SALARY FLOAT8 NOT NULL, " + "PRIMARY KEY (EMPLOYEE_ID) )";

		try {
			// get connection
			conn = JDBCUtil.getConnection(query);

			// create statement
			statement = conn.createStatement();

			// execute query
			createStatus = !statement.execute(query);

			// close connection
			statement.close();
			conn.close();

			System.out.println("Table created successfully.");
		} catch (Exception e) {
			e.printStackTrace();
		}

		return createStatus;

	}

	@Override
	public boolean createEmployeeRecord(Employee employee) {
		// TODO Auto-generated method stub
		boolean insertStatus=false;
		Connection conn = null;
		Statement statement = null;
 
		String query = "INSERT INTO EMPLOYEE(EMPLOYEE_ID,NAME,SALARY) VALUES("
			+ employee.getEmployeeId()+","
			+"'"+ employee.getName()+"'"+","
			+ employee.getSalary()+")";
 
		try{			
			//get connection
			conn = JDBCUtil.getConnection(query);
 
			//create statement
			statement = conn.createStatement();
 
			//execute query
			int count=statement.executeUpdate(query);
			if(count>0)
			{
					insertStatus=true;
				
			}
 
			//close connection
			statement.close();
			conn.close();
 
			System.out.println("Record inserted successfully");
		}catch(Exception e){
			e.printStackTrace();
		}
	
	return insertStatus;
		
		
	}

	@Override
	public boolean createEmployeeRecords(List<Employee> employeeList) {
		// TODO Auto-generated method stub
		boolean insertStatus=false;
		Connection conn = null;
		Statement statement = null;
       for(Employee  employee:employeeList)
       {
			insertStatus=createEmployeeRecord(employee);


		
		}
	
	return insertStatus;
	
	}

	public boolean updateRecordById(Employee employee) {
		// TODO Auto-generated method stub
		boolean updateStatus=false;
		Connection conn = null;
		Statement statement = null;
 
		String query = "UPDATE EMPLOYEE SET NAME = " + "'" +employee.getName()+"'"
				+",SALARY ="+employee.getSalary()+
				"WHERE EMPLOYEE_ID=" +employee.getEmployeeId();;
 
		try{			
			//get connection
			conn = JDBCUtil.getConnection(query);
 
			//create statement
			statement = conn.createStatement();
 
			//execute query
			int count=statement.executeUpdate(query);
			if(count>0)
			{
					updateStatus=true;
				
			}
 
			//close connection
			statement.close();
			conn.close();
 
			System.out.println("Record inserted successfully");
		}catch(Exception e){
			e.printStackTrace();
		}
	
	return updateStatus;
		
		
	
		
		
	}

	@Override
	public List<Employee> displayAllEmployee() {
		// TODO Auto-generated method stub
		Connection conn = null;
		Statement statement = null;
		List<Employee> mylist=new ArrayList();

		String query = "select EMPLOYEE_ID, NAME from EMPLOYEE";
 
		try{			
			//get connection
			conn = JDBCUtil.getConnection(query);
 
			//create statement
			statement = conn.createStatement();
 
			//execute query
			ResultSet rs = statement.executeQuery(query);
			while (rs.next()) {				 
				int empId = rs.getInt("EMPLOYEE_ID");
			   String empName = rs.getString("NAME");
			   double salary=rs.getDouble("SALARY");
			   Employee employee=new Employee(empId, empName, salary);
			   mylist.add(employee);
 
			   System.out.println("EmpId : " + empId);
			   System.out.println("EmpName : " + empName); 
			   System.out.println("Salary :" + salary);
			}
 
			//close connection
			statement.close();
			conn.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return mylist;

	}

	@Override
	public Employee displayAllEmployeeBuyId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteAllEmployee() {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deteleAllEmployeeById() {
		// TODO Auto-generated method stub
		return false;
	}

}
