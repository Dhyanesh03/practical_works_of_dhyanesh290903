package com.hexaware.services;

import java.util.List;

import com.hexaware.entities.Employee;

public interface IServiceProvider {
	//ddl--- create table
	public boolean createEmployeeTable();
	//Dml---insert single
	public boolean createEmployeeRecord(Employee employee);
	//Dml==multi line import
	public boolean createEmployeeRecords(List<Employee> employeeList);
	//Dml--update
	public boolean updateRecordById(int id);
	//Dql--displayall
	public List<Employee> displayAllEmployee();
	//Dql---displayy alll by id
	public Employee displayAllEmployeeBuyId();
	//Dql--delete all employee
	public boolean deleteAllEmployee();
	//DQl-delete by id
	public boolean deteleAllEmployeeById();
	
}
