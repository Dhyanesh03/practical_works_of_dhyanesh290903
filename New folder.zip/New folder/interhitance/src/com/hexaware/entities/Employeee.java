package com.hexaware.entities;

public class Employeee {

}
