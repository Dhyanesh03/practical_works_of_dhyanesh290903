package com.hexaware.entities;

public class Person {

}
