package com.hexaware.mainmod;

public class MainMod {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
