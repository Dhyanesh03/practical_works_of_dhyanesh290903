package com.hexaware.strings;

public class Strings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
