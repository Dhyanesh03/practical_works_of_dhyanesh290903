package com.hexaware.hashcodedemao;

public class Car {

}
